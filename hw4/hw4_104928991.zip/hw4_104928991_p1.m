% The Pendulum Problem
% Model the motion of a simple pendulum
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% Create constants
L = 1;
g = 9.81;
t = linspace(0,20,4001); % array of time spaced evenly from 0 to 20
a = zeros(1, 4001); % array of 0's
a = a + (-g/L); % a is now filled with (-g/L)
w = zeros(1, 4001); % array of 0's
theta = zeros(1, 4001); % array of 0's
theta(1) = pi/3; % first position
a(1) = a(1) * sin(theta(1)); % first acceleration

% Calculate values using euler's method
for i = 2:4001
    w(i) = w(i-1) + a(i-1)*0.005;
    theta(i) = theta(i-1) + w(i)*0.005;
    a(i) = a(i) * sin(theta(i));
end

% Calculate total energy
h = (L*cos(theta)) - L*cos(pi/3); % calculate height using trigonomerty
E = g*h + 0.5*(L*w).^2; % array representing total energy

% Plot pendulum motion as a function of time
figure(1);
plot(t, theta, t, w, t, a);

% Plot total energy as a function of time
figure(2);
plot(t, E);