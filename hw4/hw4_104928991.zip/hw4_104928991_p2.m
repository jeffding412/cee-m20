% DNA Analysis
% Calculate the lengths of protein-coding segments in a DNA segment array
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% Loads DNA segment array
load('chr1_sect.mat');

% Creates array that holds the lengths of segments, which at first is zero
numBases = length(dna);
lengthArray = zeros(1, numBases);

% Loop to calculate length of segments
lengthIndex = 0; % slightly unneccesary, holds current index of lengthArray
startPoint = 0; % stores index of start of segment

for k = 1:3:numBases-2
    % Segment start tag
    if dna(k) == 1 && dna(k+1) == 4 && dna(k+2) == 3
        startPoint = k;
        for i = startPoint+3:3:numBases-2
            % Checks for end tags
            if (dna(i) == 4 && dna(i+1) == 1 && dna(i+2) == 3) || (dna(i) == 4 && dna(i+1) == 1 && dna(i+2) == 1) || (dna(i) == 4 && dna(i+1) == 3 && dna(i+2) == 1)
                % Stores length into lengthArray
                lengthIndex = lengthIndex+1;
                lengthArray(lengthIndex) = i - startPoint + 3;
                k = i; % Start searching for new segment after end tag
                break;
            end
        end
    end
end

% Creates array full of zeros to hold lengths
newLengthArray = zeros(1, lengthIndex);

% Copies lengths into newLengthArray
for x = 1:lengthIndex
    newLengthArray(x) = lengthArray(x);
end

% Prints data
fprintf('Total Protein-Coding Segments: %.0f\n', length(newLengthArray));
fprintf('Average Length: %.2f\n', mean(newLengthArray));
fprintf('Maximum Length: %.0f\n', max(newLengthArray));
fprintf('Minimum Length: %i\n', min(newLengthArray));