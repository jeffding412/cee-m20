% Newton's Method
% Create a script to run a zero-finding method Newton's method
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% function and constants
complicatedCubic = @(x) 816*x.^3 - 3835*x.^2 + 6000*x + -3125;
d = 10^-21;
fEvalMax = 10;

% initial guess
x0 = 1.43;

% iterate through guesses
while x0 <= 1.71
    [xc, fEvals] = Newton(complicatedCubic, x0, d, fEvalMax);
    fprintf("x0 = %.2f, evals = %d, xc = %.6f\n", x0, fEvals, xc);
    x0 = x0 + 0.01;
end