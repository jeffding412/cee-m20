% Spatial Hashing
% Map particle data onto a 2D grid by discretizing
% entire domain into a series of rectangular bins
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% constants
N = 20;   % number of particles
h = 0.25; % minimum bin dimension
% sets grid
xMax = 1; 
yMax = 1;
% bins
Nx = floor(xMax/h); % number of columns
Ny = floor(yMax/h); % number of rows
% bin dimensions
dx = xMax/Nx;
dy = yMax/Ny;

% constructing N particles
x = rand(1, N);
y = rand(1, N);

% assign bin numbers
binNum = zeros(1, N);
for index = 1:N
    binNum(index) = (ceil(x(index)/dx)-1)*Ny + ceil((yMax-y(index))/dy);
end

% calculate bin averages
binAvgX = zeros(1, Nx*Ny);
binAvgY = zeros(1, Nx*Ny);
for binIndex = 1:Nx*Ny
    averageX = 0;   % average x location
    averageY = 0;   % average y location
    count = 0;
    for index = 1:N
        if binNum(index) == binIndex
            averageX = averageX + x(index);
            averageY = averageY + y(index);
            count = count + 1;
        end
    end
    binAvgX(binIndex) = averageX/count;
    binAvgY(binIndex) = averageY/count;
end

% plot data
scatter(x, y, 50, 'b', 'filled');
hold on;
scatter(binAvgX, binAvgY, 25, 'r', 'x');
grid on;
xticks(0:dx:xMax);
yticks(0:dy:yMax);

% print data
for binIndex = 1:Nx*Ny
    matches = 0;
    fprintf("Bin %d: ", binIndex);
    for index = 1:N
        if binNum(index) == binIndex
            matches = matches + 1;
            fprintf("%d ", index);
        end
    end
    if matches == 0
        fprintf("[]\n");
    else
        fprintf("\n");
    end
end