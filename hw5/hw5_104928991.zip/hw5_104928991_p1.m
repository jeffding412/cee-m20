% The Split-and-Average Problem
% Script that repeatedly splits and averages
% a set of x and y points and plot the initial points as unconnected nodes
% Repeat the process of splitting and averaging until the maximum
% node displacement after a single split-and-average iteration 
% is less than 1 � 10^3. 
% Then plot the final distribution of points on the same axes
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% x = [1, 5, 8];

% x, y, and w arrays
x = [0.5, 0, 0.5, 1];
y = [0, 0.5, 1, 0.5];
w = [0, -2, 10];

maxDisplacement = 1;

initialX = x;
initialY = y;

while maxDisplacement > 10^-3
    % initial split
    xs = splitPts(x);
    ys = splitPts(y);
   
    % find averages
    xa = averagePts(xs, w);
    ya = averagePts(ys, w);
   
    % redistribute
    x = xa;
    y = ya;

    % calculate difference
    dx = xa - xs;
    dy = ya - ys;
    maxDisplacement = max(sqrt(dx.^2 + dy.^2));
end

% initial plot
figure(1);
plot(initialX, initialY, '.');

% finished plot
figure(2);
plot(x, y, '.');