function [ xa ] = averagePts( xs, w )
% averagePts takes two inputs: vector, xs, 
% and [1x3] vector, w, of weighting averages
% and returns a vector, xs, with each element being
% the weighted average of the three nearest neighbors,
% including the current element itself
% The average is calculated:
%
% xa(k) = w1*xs(k-1) + w2*xs(k) + w3*xs(k+1)
%

% Clean up MATLAB workspace
clc;
close all;

% Catch illegal w vectors
if length(w) ~= 3
    error("Vector w not of correct size");
elseif sum(w) == 0
    error("Sum of the three weights is equal to zero");
end

% Determine the size of the input
N = length(xs);

% Create return vector xa 
xa = zeros(1, N);

% Weighted averages
w1 = w(1)/sum(w);
w2 = w(2)/sum(w);
w3 = w(3)/sum(w);

% Fill vector with weighted averages
for k = 1:N
    if k == 1
        xa(k) = w1*xs(N) + w2*xs(k) + w3*xs(k+1);
    elseif k == N
        xa(k) = w1*xs(k-1) + w2*xs(k) + w3*xs(1);
    else
        xa(k) = w1*xs(k-1) + w2*xs(k) + w3*xs(k+1);
    end
end