% Runge-Kutta Radioactivity
% Create a program that approximates carbon-15 levels using
% three different types of approximations
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% calculate actual numbers
t1 = linspace(0, 15, 16);
t2 = linspace(0, 15, 151);
t3 = linspace(0, 15, 1501);
real1 = exp(-(log(2)/2.45)*t1);
real2 = exp(-(log(2)/2.45)*t2);
real3 = exp(-(log(2)/2.45)*t3);

% different time steps
dt = [1, 0.1, 0.01];

% dt = 1.00
rk11 = ones(1, 16);
rk12 = ones(1, 16);
rk13 = ones(1, 16);

% dt = 0.10
rk21 = ones(1, 151);
rk22 = ones(1, 151);
rk23 = ones(1, 151);

% dt = 0.01
rk31 = ones(1, 1501);
rk32 = ones(1, 1501);
rk33 = ones(1, 1501);

% calculate for dt = 1.00
for t = 2:16
    rk11(t) = advanceRK(rk11(t-1), dt(1), 1);
    rk12(t) = advanceRK(rk12(t-1), dt(1), 2);
    rk13(t) = advanceRK(rk13(t-1), dt(1), 4);
end

% calculate for dt = 0.10
for t = 2:151
    rk21(t) = advanceRK(rk21(t-1), dt(2), 1);
    rk22(t) = advanceRK(rk22(t-1), dt(2), 2);
    rk23(t) = advanceRK(rk23(t-1), dt(2), 4);
end

% calculate for dt = 0.01
for t = 2:1501
    rk31(t) = advanceRK(rk31(t-1), dt(3), 1);
    rk32(t) = advanceRK(rk32(t-1), dt(3), 2);
    rk33(t) = advanceRK(rk33(t-1), dt(3), 4);
end

% calculate errors
error11 = abs(rk11 - real1);
error12 = abs(rk12 - real1);
error13 = abs(rk13 - real1);
error21 = abs(rk21 - real2);
error22 = abs(rk22 - real2);
error23 = abs(rk23 - real2);
error31 = abs(rk31 - real3);
error32 = abs(rk32 - real3);
error33 = abs(rk33 - real3);

% prints average error
fprintf('  dt          RK1           RK2            RK4\n');
fprintf('1.00:    %.2e      %.2e       %.2e\n', mean(error11), mean(error12), mean(error13));
fprintf('0.10:    %.2e      %.2e       %.2e\n', mean(error21), mean(error22), mean(error23));
fprintf('0.01:    %.2e      %.2e       %.2e\n', mean(error31), mean(error32), mean(error33));

% plots dt = 1.00
figure(1);
plot(t1, rk11, t1, rk12, t1, rk13, t1, real1);

% plots dt = 0.10
figure(2);
plot(t2, rk21, t2, rk22, t2, rk23, t2, real2);

% plots dt = 0.01
figure(3);
plot(t3, rk31, t3, rk32, t3, rk33, t3, real3);