function [ y ] = advanceRK( y, dt, method)
% advanceRK takes three inputs: 
% a scaler, y, representing current amount of carbon-15,
% a scaler, dt, representing timestep size,
% and a scaler, method, to determine whether to use
% 1st, 2nd, or 4th order approximation
% Function returns a scaler y to advance the
% discretized solution by one timestep
% The methods are:
%
% 1: first-order
% 2: second-order
% 4: fourth-order
%

% Clean up MATLAB workspace
clc;
close all;

% Calculate differential of carbon-15 decay
dydt = ((-log(2))/2.45)*y;
c1 = dt*dydt;
dydt = ((-log(2))/2.45)*(y+0.5*c1);
c2 = dt*dydt;
dydt = ((-log(2))/2.45)*(y+0.5*c2);
c3 = dt*dydt;
dydt = ((-log(2))/2.45)*(y+c3);
c4 = dt*dydt;

% Determine which method to return
switch method
    case 1
        y = y + c1;
    case 2
        y = y + c2;
    case 4
        y = y + (1/6)*c1 + (1/3)*c2 + (1/3)*c3 + (1/6)*c4;
    otherwise
        error("Invalid method number");
end

end