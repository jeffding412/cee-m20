function [ xs ] = splitPts( x )
% splitPts takes a single input vector, x, and returns an output
% vector, xs, with twice the number of element as x, 
% where midpoints are inserted every-other element 
% with a value equal to the average of the neighboring elements. 
% The average is calculated:
%
% average = (x_1 + x_2)/2
%

% Clean up MATLAB workspace
clc;
close all;

% Determine the size of the input
N = length(x);

% Create return vector xs 
xs = zeros(1, N*2);

% Set odd indexes using original points
xIndex = 1;
for k = 1:2:N*2
    xs(k) = x(xIndex);
    xIndex = xIndex + 1;
end

% Set even indexes by calculating averages
for k = 2:2:N*2
    if k == N*2
        xs(k) = (xs(k-1) + xs(1))/2;
    else
        xs(k) = (xs(k-1) + xs(k+1))/2;
    end
end

end