% Ellipse Calculations 
% Given an ellipse with semiaxes a and b, 
% approximates a and b and
% prints the values of P1,...,P8 in a way that facilitates comparison
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% Input a and b
a = input('Enter "a" value: ');
b = input('Enter "b" value: ');

% Approximation Calculations
h = ((a-b)/(a+b))^2;
P1 = pi*(a+b);
P2 = pi*sqrt(2*(a^2 + b^2));
P3 = pi*sqrt(2*(a^2 + b^2) - ((a-b)^2)/2);
P4 = pi*(a+b)*((1 + h/8)^2);
P5 = pi*(a+b)*(1 + (3*h)/(10+sqrt(4-3*h)));
P6 = pi*(a+b)*((64-3*h^2)/(64-16*h));
P7 = pi*(a+b)*((256-48*h-21*h^2)/(256-112*h+3*h^2));
P8 = pi*(a+b)*((3-sqrt(1-h))/2);

% Prints out information
fprintf('a = %10.5f, b = %10.5f\n', a, b);
fprintf('P1 = %10.15f\n', P1);
fprintf('P2 = %10.15f\n', P2);
fprintf('P3 = %10.15f\n', P3);
fprintf('P4 = %10.15f\n', P4);
fprintf('P5 = %10.15f\n', P5);
fprintf('P6 = %10.15f\n', P6);
fprintf('P7 = %10.15f\n', P7);
fprintf('P8 = %10.15f\n', P8);
fprintf('h = %10.15f\n', h);