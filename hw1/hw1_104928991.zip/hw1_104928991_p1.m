% Polyhedron Properties 
% prints a table showing the inradius, outradius, and edge length of nested Platonic solids of:
% the largest tetrahedron that fits inside the unit sphere
% the largest cube that fits inside that
% the largest octahedron that fits inside that
% the largest dodecahedron that fits inside that
% the largest iscosahedron that fits inside that
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% Tetrahedron Calculations
R4 = 1;
E4 = R4/(sqrt(6)/4);
r4 = (sqrt(6)/12)*E4;

% Cube Calculations
R6 = r4;
E6 = R6/(sqrt(3)/2);
r6 = (1/2)*E6;

% Octahedron Calculations
R8 = r6;
E8 = R8/(sqrt(2)/2);
r8 = (sqrt(6)/6)*E8;

% Dodecahedron Calculations
R12 = r8;
E12 = R12/((sqrt(15)+sqrt(3))/4);
r12 = (sqrt(250 + 110*sqrt(5))/20)*E12;

% Iscosahedron Calculations
R20 = r12;
E20 = R20/(sqrt(10 + 2*sqrt(5))/4);
r20 = (sqrt(42+18*sqrt(5))/12)*E20;

% Prints the table of information
fprintf('Solid | inradius | outradius | edge length |\n');
fprintf('--------------------------------------------\n');
fprintf('Tetra | %1.6f | %1.6f  | %1.6f    |\n', r4, R4, E4);
fprintf('Cube  | %1.6f | %1.6f  | %1.6f    |\n', r6, R6, E6);
fprintf('Octah | %1.6f | %1.6f  | %1.6f    |\n', r8, R8, E8);
fprintf('Dodec | %1.6f | %1.6f  | %1.6f    |\n', r12, R12, E12);
fprintf('Icosa | %1.6f | %1.6f  | %1.6f    |\n', r20, R20, E20);