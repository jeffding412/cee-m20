% Circle-Circle Intersections
% Given Circle 1 centered at (x1, y1) and Circle 2 centered at (x2, y2)
% r1 and r2 are their respective radii
% calculates the area of the lens formed by two intersecting circles
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% Prompts user for inputs
x1 = input('Enter x1 value: ');
y1 = input('Enter y1 value: ');
r1 = input('Enter r1 value: ');
x2 = input('Enter x2 value: ');
y2 = input('Enter y2 value: ');
r2 = input('Enter r2 value: ');

% Calculates seperation distance between two circles
d = sqrt((x2-x1)^2 + (y2-y1)^2);

% Calculates chord length of intersection of two circles
c = sqrt((-d+r1+r2)*(d-r1+r2)*(d+r1-r2)*(d+r1+r2))/d;

% Calculates area of the lens
Area = (r1^2)*acos((d^2+r1^2-r2^2)/(2*d*r1)) + (r2^2)*acos((d^2-r1^2+r2^2)/(2*d*r2)) - (d/2)*c;

% Prints the information
fprintf('\nx1 = %5.2f\n', x1);
fprintf('y1 = %5.2f\n', y1);
fprintf('r1 = %5.2f\n', r1);
fprintf('x2 = %5.2f\n', x2);
fprintf('y2 = %5.2f\n', y2);
fprintf('r2 = %5.2f\n', r2);
fprintf('\nArea = %5.4f\n', Area);