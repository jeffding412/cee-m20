% Simulated Annealing
% Simulated annealing algorithm that finds
% the shortest, fully-closed path between N
% randomly-positioned points on a 2D grid
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% create arrays
% represents the x and y positions of each node
N = 10;
x = rand(1, N);
y = rand(1, N);
path = randperm(N);

% determine the length of the initial path
distance = getPathDistance(x, y, path);

% tracks shortest distance as a function of iteration
shortest = zeros(1, 1379);
shortestIndex = 0;

% simulated annealing
T = 1000;
while (T > 1)
    % puts shortest distance at each iteration
    shortestIndex = shortestIndex+1;
    shortest(shortestIndex) = distance;
    
    pathNew = path;
    % swap exactly 2 randomly-chosen nodes in path to form pathNew
    firstIndex = floor(rand(1, 1)*N) + 1;
    secondIndex = firstIndex;
    while firstIndex == secondIndex
        secondIndex = floor(rand(1, 1)*N) + 1;
    end
    tempNode = pathNew(firstIndex);
    pathNew(firstIndex) = pathNew(secondIndex);
    pathNew(secondIndex) = tempNode;
    
    % calculate distNew, the length of the new path
    distNew = getPathDistance(x, y, pathNew);
    
    % calculate the difference in path length, ?L = distNew - distance
    deltaL = distNew - distance;
    
    % If the new path is shorter than the old path, ?L < 0, or p > rand
    % then update the path vector and dist value to reflect the new route
    % exploration metric, p = exp(?c?L/T) with c = 1000
    % rand is a uniformly distributed random value in the range (0, 1).
    c = 1000;
    p = exp(-c*deltaL/T);
    
    if deltaL < 0 || p > rand(1, 1)
        path = pathNew;
        distance = distNew;
    end
    
    % ?cool? the simulation according to T = T(1 ? ?) 
    % where the decay rate, ? = 0.005
    T = T*(1-0.005);
end

% reassign x and y values into a new X and Y coordinate 
% in the order of path
newX = zeros(1, N+1);
newY = zeros(1, N+1);
for k = 1:N
    currentIndex = path(k);
    newX(k) = x(currentIndex);
    newY(k) = y(currentIndex);
end
newX(N+1) = x(path(1));
newY(N+1) = y(path(1));

% plot results
figure(1);
plot(newX, newY, 'o-');
figure(2);
plot(shortest);