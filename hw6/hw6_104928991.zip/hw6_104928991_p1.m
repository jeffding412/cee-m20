% The Shared Birthday Problem
% How many people are required in a group before it is more likely than
% not that any two of their birthdays occur in the same week? 
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% array of trials holding number of people in group
trials = zeros(1, 10^4);
trialIndex = 1;

while (trialIndex <= 10^4)
    % array of people in the group
    group = zeros(1, 53);
    groupIndex = 0;
    found = 0;
    while(found ~= 1)
        groupIndex = groupIndex + 1;
        % add person into group
        group(groupIndex) = floor(rand(1, 1)*365) + 1;
        % if person is within a week from someone else in group, add number of
        % people into trials
        for k = 1:groupIndex-1
            if abs(group(groupIndex)-group(k)) < 7
                % add number of people into trial
                trials(trialIndex) = groupIndex;
                trialIndex = trialIndex + 1;
                found = 1;
                break;
            elseif group(groupIndex) + 7 > 365
                if abs(group(groupIndex)-365-group(k)) < 7
                    % add number of people into trial
                    trials(trialIndex) = groupIndex;
                    trialIndex = trialIndex + 1;
                    found = 1;
                    break;
                end
            elseif group(groupIndex) - 7 < 1
                if abs(group(groupIndex)+365-group(k)) < 7
                    % add number of people into trial
                    trials(trialIndex) = groupIndex;
                    trialIndex = trialIndex + 1;
                    found = 1;
                    break;
                end
            end
        end
    end
end

% create results
median = median(trials);
fprintf("Median Number of People = %d\n", median);
histogram(trials);