function dist = getPathDistance(x, y, path)
% getPathDistance takes three inputs: 
% a vector, x, representing x coordinates,
% a vector, y, representing y coordinates,
% and a vector, path, a permutation of the values 
% describing the order of visitation
% Function returns a scaler, dist, representing the sum of
% the Euclidean distances between successive nodes in the path
% Each segment in the trip can be computed according to:
%
% ab = sqrt((xb-xa)^2 + (yb-ya)^2)
%

% Clean up MATLAB workspace
clc;
close all;

% set up number of nodes and return value
nodes = length(path);
dist = 0;

% calculate first N-1 visitations
for k = 2:nodes
    a = path(k-1);
    b = path(k);
    dist = dist + sqrt((x(b)-x(a))^2 + (y(b)-y(a))^2);
end

% calculate last visitation from last node to first node
dist = dist + sqrt((x(nodes)-x(1))^2 + (y(nodes)-y(1))^2);