% Euler-Bernoulli Beam Bending
% Solve a system of equations 
% to study the displacement of a simply-supported
% aluminum beam subjected to a single point load
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% declare constants
L = 1;     % bar length
R = 0.013; % circular-tube cross section outer radius
r = 0.011; % circular-tube cross section inner radius
P = 2000;  % applied force
d = 0.75;  % distance of applied force
E = 70*10^9;     % modulus of elasticity
I = (pi/4)*(R^4-r^4); % moment of inertia of the cross section

% create x array
x = linspace(0, L, 100);

% create matrix A of 20 evenly spaced node representing the bar
A = zeros(length(x), length(x));

% discretize for all the interior points 
% using the central, second-derivative stencil
A(1,1) = 1;
A(length(x),length(x)) = 1;
for row = 2:length(x)-1
    A(row,row-1) = 1;
    A(row,row) = -2;
    A(row,row+1) = 1;
end

% form right-hand side matrix
b = zeros(length(x),1);
for index = 2:length(x)-1
    b(index,1) = ((x(index)-x(index-1))^2)/(E*I);
    if x(index) <= d
        b(index,1) = b(index,1)*(P*(L-d)*x(index))/L;
    else
        b(index,1) = b(index,1)*(P*d*(L-x(index)))/L;
    end
end

% solve system of equations
y = A\b;
[yMax, yIndex] = min(y);
xIndex = x(yIndex);

% find theoretical y-max
c = min(d, L-d);
yMaxTheoretical = (-P*c*(L^2-c^2)^1.5)/(9*sqrt(3)*E*I*L);

error = abs((yMaxTheoretical - yMax)/yMaxTheoretical)*100;

% plot
plot(x, y, 'o-');