% The Game of Life
% Simulate the fate of living cells 
% using the rules from mathematician 
% John Conway's famous Game of Life
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% initialize size of 2D array
num_rows = 150;
num_cols = 200;
grid = zeros(num_rows, num_cols);

% tracks alive cells
livingCells = zeros(1, 300);
livingCellsIndex = 1;
aliveCells = 0;

% 1/10 cells are alive
for row = 1:num_rows
    for col = 1:num_cols
        if floor(rand()*10) == 0
            grid(row, col) = 1;
            aliveCells = aliveCells + 1;
        end
    end
end
livingCells(livingCellsIndex) = aliveCells;

% run simulation for 300 generations
generations = 1;
while generations < 300
    livingCellsIndex = livingCellsIndex + 1;
    aliveCells = 0;
    newGrid = grid;
    for row = 1:num_rows
        for col = 1:num_cols
            currentCell = grid(row, col);
            neighborSum = 0;

            % identify neighboring indices
            N = row - 1;
            S = row + 1;
            E = col + 1;
            W = col - 1;

            % update indices if on edge and/or corners
            if N < 1
                N = num_rows;
            end
            if S > num_rows
                S = 1;
            end
            if W < 1
                W = num_cols;
            end
            if E > num_cols
                E = 1;
            end

            % sum neighboring cells
            neighborSum = grid(N, W) + grid(N, col) + grid(N, E) + grid(row, W) + grid(row, E) + grid(S, W) + grid(S, col) + grid(S, E);

            % update current cell
            if currentCell == 1 && neighborSum ~= 2 && neighborSum ~= 3
                newGrid(row, col) = 0;
            elseif currentCell == 0 && neighborSum == 3
                newGrid(row, col) = 1;
            end
        end
    end
    % update grid
    grid = newGrid;
    for row = 1:num_rows
        for col = 1:num_cols
            if grid(row, col) == 1
                aliveCells = aliveCells + 1;
            end
        end
    end
    livingCells(livingCellsIndex) = aliveCells;
    generations = generations + 1;
    
    % animate results
    imagesc(grid);
    drawnow;
end

% plot number of living cells as a function of time
plot(livingCells);
