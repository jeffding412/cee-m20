% The Three Species Problem
% Model three groups of imaginary creatures X, Y, and Z competing for the same food using the Lotka-Volterra equations
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% initial populations
x = 2;
y = 2.49;
z = 1.5;

% Lotka-Volterra equations
dxdt = 0.75*x*(1 - x/20) - 1.5*x*y - 0.5*x*z;
dydt = y*(1 - y/25) - 0.75*x*y - 1.25*y*z;
dzdt = 1.5*z*(1 - z/30) - x*z - y*z;

% Print Data
fprintf('  Time       X       Y       Z\n');
for t = 0:0.001:12
    % Only print by 0.5 steps
    if rem(t, 0.5) == 0
        fprintf(' %5.1f   %5.2f   %5.2f   %5.2f\n', t, x, y, z);
    end
    % Recalculate data
    dxdt = 0.75*x*(1 - x/20) - 1.5*x*y - 0.5*x*z;
    dydt = y*(1 - y/25) - 0.75*x*y - 1.25*y*z;
    dzdt = 1.5*z*(1 - z/30) - x*z - y*z;
    % Forward Euler method
    x = x + dxdt * 0.001;
    y = y + dydt * 0.001;
    z = z + dzdt * 0.001;
end