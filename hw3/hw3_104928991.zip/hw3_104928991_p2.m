% The Pocket Change Problem
% What is the average number of coins you can expect to receive in your change after a cash transaction?
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% Tracks total number of coins
totalCoins = 0;

% For loop that calculates total number of coins
for totalChange = 99:-1:0
    % Holds how much cash still needed to be converted
    remainingCash = totalChange;
    % While there still is cash
    while remainingCash > 0
        if remainingCash >= 25  % quarters
            remainingCash = remainingCash - 25;
        elseif remainingCash >= 10  % dimes 
            remainingCash = remainingCash - 10;
        elseif remainingCash >= 5   % nickels
            remainingCash = remainingCash - 5;
        else    %pennies
            remainingCash = remainingCash - 1;
        end
        totalCoins = totalCoins + 1;
    end
end

% Prints average number of coins
fprintf('Average Number of Coins = %.2f\n', totalCoins/100);