% Nested Radicals
% Calculate nested radicals using an user-input value
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

m = 0;

% Prompt user for valid input
while 1
    m = input('Input a number greater than 1: ');
    % If valid input, get out of while loop
    if rem(m,1) == 0 && m > 1
        break;
    end
    fprintf('m is not a valid input\n');
end

tol = 10^-12;           %tolerance
tOdd = sqrt(m);         
tEven = sqrt(m-tOdd);   
err = tEven - tOdd;     %difference between successive terms
count = 4;              %tracks term number

fprintf('m = %.0f\n', m);
fprintf('t1 = %.12f\n', tOdd);
fprintf('t2 = %.12f\n', tEven);

if abs(err) >= tol
    tOdd = sqrt(m-sqrt(m+sqrt(m)));
    fprintf('t3 = %.12f\n', tOdd);
    err = tOdd-tEven;
end

% Keep displaying pattern until difference between successive terms is less
% than the tolerance
while abs(err) >= tol
    if rem(count, 2) == 1   %Odd terms
        tOdd = sqrt(m-sqrt(m+tOdd));
        fprintf('t%.0f = %.12f\n', count, tOdd);
        err = tOdd-tEven;
    else %Even terms
        tEven = sqrt(m-sqrt(m+tEven));
        fprintf('t%.0f = %.12f\n', count, tEven);
        err = tEven-tOdd;
    end
    count = count + 1;
end
