% Classifying Cubic Functions
% check whether or not a cubic function is simple or monotone
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% Prompts user for inputs
a = input('Input a: ');
b = input('Input b: ');
c = input('Input c: ');
d = input('Input d: ');

% Error handling
if a == 0
    error('a cannot be 0!');
end

% Print inputs
fprintf('a = %10.6f\n', a);
fprintf('b = %10.6f\n', b);
fprintf('c = %10.6f\n', c);
fprintf('d = %10.6f\n', d);

% Derative coefficients
qa = 3*a;
qb = 2*b;
qc = c;

% Calculates roots of derative
r1 = (-qb + sqrt(qb^2 - 4*qa*qc))/(2*qa);
r2 = (-qb - sqrt(qb^2 - 4*qa*qc))/(2*qa);

% Plug derative roots into original equations
qr1 = a*r1^3 + b*r1^2 + c*r1 + d;
qr2 = a*r2^3 + b*r2^2 + c*r2 + d;

% Print results
if ~isreal(r1) || ~isreal(r2)
    fprintf('Monotone\n');
else
    fprintf('r1 = %10.6f\n', r1);
    fprintf('q(r1) = %10.6f\n', qr1);
    fprintf('r2 = %10.6f\n', r2);
    fprintf('q(r2) = %10.6f\n', qr2);
    if (qr1*qr2) < 0        %decides if function is simple
        fprintf('Function q is simple\n');
    else                    %not simple
        fprintf('Function q is NOT simple.\n')
    end
end


