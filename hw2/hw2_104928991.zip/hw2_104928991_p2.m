% Neighbor Identification
% identify all neighbors of a given cell in a rectangular array
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% Inputs
M = input('Input rows: ');
N = input('Input columns: ');
P = input('Input identification cell: ');

% Error handle inputs
if M < 2 || N < 2
    error('M or N is less than 2');
elseif P < 1 || P > (M*N)
    error('P is invalid');
elseif rem(M,1) ~= 0 || rem(N,1) ~= 0 || rem(P,1) ~= 0
    error('M, N, and/or P are invalid');
end

% Print statements
fprintf('\nCell ID: %.0f\n', P);
fprintf('Neighbors: ');

if P == 1             %upper-left corner
    fprintf('2 %.0f %.0f', P+M, P+M+1);
elseif P < M          %left side
    fprintf('%.0f %.0f %.0f %.0f %.0f', P-1, P+1, P+M-1, P+M, P+M+1);
elseif P == M         %lower-left corner
    fprintf('%.0f %.0f %.0f', P-1, P+M-1, P+M);
elseif P == M*N       %lower-right corner
    fprintf('%.0f %.0f %.0f', P-M-1, P-M, P-1);
elseif P == M*N-M+1   %upper-right corner
    fprintf('%.0f %.0f %.0f', P-M, P-M+1, P+1);
elseif rem(P, M) == 0 %top row
    fprintf('%.0f %.0f %.0f %.0f %.0f', P-M-1, P-M, P-1, P+M-1, P+M);
elseif rem(P, M) == 1 %bottom row
    fprintf('%.0f %.0f %.0f %.0f %.0f', P-M, P-M+1, P+1, P+M, P+M+1);
elseif P > M*N-M+1    %right side
    fprintf('%.0f %.0f %.0f %.0f %.0f', P-M-1, P-M, P-M+1, P-1, P+1);
else                  %interior
    fprintf('%.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f', P-M-1, P-M, P-M+1, P-1, P+1, P+M-1, P+M, P+M+1);
end

fprintf('\n');