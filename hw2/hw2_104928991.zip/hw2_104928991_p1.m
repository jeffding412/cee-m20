% The Lunar Phase Calculator 
% estimates the lunar phase by knowing two things:
% (i) the number of days between the user-input date and a known new-moon date 
%   (in this case, we?ll use the new moon that occurred on January 1, 1900)
% (ii) the number of days in each lunar revolution
% returns the lunar phase for a user-specified date
% Zhengfu Ding 104928991

% Clear terminal and workspace
clear all;
clc;

% Take in month input
month = input('Please enter the month as MMM (e.g. JAN): ', 's');
% Gives each month a numeric value
monthNum = 0;
if strcmp(month, 'JAN')
    monthNum = 1;
elseif strcmp(month, 'FEB')
    monthNum = 2;
elseif strcmp(month, 'MAR')
    monthNum = 3;
elseif strcmp(month, 'APR')
    monthNum = 4;
elseif strcmp(month, 'MAY')
    monthNum = 5;
elseif strcmp(month, 'JUN')
    monthNum = 6;
elseif strcmp(month, 'JUL')
    monthNum = 7;
elseif strcmp(month, 'AUG')
    monthNum = 8;
elseif strcmp(month, 'SEP')
    monthNum = 9;
elseif strcmp(month, 'OCT')
    monthNum = 10;
elseif strcmp(month, 'NOV')
    monthNum = 11;
elseif strcmp(month, 'DEC') 
    monthNum = 12;
end

% Take in day input
day = input('Please enter the day as DD (e.g. 01): ', 's');
dayNum = str2num(day);  % Converts day into an int

% Take in year input
year = input('Please enter the year as YYYY (e.g. 2000): ', 's');
yearNum = str2num(year);    % Converts year into an int

if isempty(dayNum) || isempty(yearNum)
    error('Invalid month');
end

% Checks if it is a valid month
if monthNum == 0 || monthNum > 12
    error('Invalid month');
end

% Checks if day is valid in format and logic
if length(day) ~= 2 || dayNum <= 0 || dayNum > 31 || (rem(dayNum, 1) ~= 0)
    error('Invalid day');
end

% Checks whether or not the month and day combination is valid except FEB
if (monthNum == 4 || monthNum == 6 || monthNum == 9 || monthNum == 11) && dayNum > 30  
    error('Invalid date');
end

% Checks if year is valid in format, logic, and between 1990 and 9999
if length(year) ~= 4 || yearNum < 1900 || yearNum > 9999
    error('Invalid year');
end

% Checks for leap year
if monthNum == 2 && rem(yearNum, 4) ~= 0 && dayNum > 28
    error('Not a leap year and/or invalid date');
elseif monthNum == 2 && rem(yearNum, 4) == 0 && dayNum > 29
    error('Invalid date');
end

% Calculates elapsed number of days since the new moon
% Calculates the offset value
a = 0;
if monthNum == 1 || monthNum == 2
    a = 1;
end
% Calculates the elapsed number of days, represented by deltaJ
y = yearNum - a + 4800;
m = monthNum + 12*a - 3;
J = dayNum + floor((153*m + 2)/5) + 365*y + floor(y/4) - floor(y/100) + floor(y/400) - 32045;
deltaJ = J - 2415021;

% Calculates the illumination and phase
T = 29.530588853;
phaseCalc = (rem(deltaJ, T))/T;
L = (sin(pi*phaseCalc))^2;

% Print data
fprintf('%s %s %s:\n', month, day, year);
fprintf('Illumination = %.1f percent\n', L*100);
if phaseCalc < 0.5
    fprintf('Waxing\n');
else
    fprintf('Waning\n');
end